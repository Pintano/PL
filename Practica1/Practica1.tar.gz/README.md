Para introducir manualmente las expresiones:
    make normal

Para introducir las expresiones de un fichero:
    make doc file=nombre_del_fichero
    make doc file=EjemploReconocimiento